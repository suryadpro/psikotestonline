<?php session_start(); 
include "sql_connect.php"; 
$username=$_POST['user_name']; 
$password=$_POST['password']; 
$query=mysql_query("select * from admin where user_name='$username' and password='$password'"); 
$cek=mysql_num_rows($query);
$row=mysql_fetch_array($query); 
if($cek){ 
 $_SESSION['id']=$row['id_admin'];
 $_SESSION['user_name']=$username;
 $_SESSION['level'] =$row['level'];
  
echo '<meta http-equiv="refresh" content="0;url=menu.php" />';  exit;
}else{ 
echo '<meta http-equiv="refresh" content="0;url=index.php" />';   exit;
 echo mysql_error(); 
} 
?> 