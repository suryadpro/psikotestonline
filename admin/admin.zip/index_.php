<?php
if ($_GET['destroy'] == "yes") { session_destroy(); }
require('menu_login.php');
?>