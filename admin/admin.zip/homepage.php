<html>
<head>
<title> Psikotes Online Persada</title>
<frameset rows="96%,5%"frameborder="yes"border="0">
<frame src="menu_login.php"name="frame tengah"background="image/background.png">
<frame src="footer.php"name="frame bawah">
</frameset>
</head>
</html>