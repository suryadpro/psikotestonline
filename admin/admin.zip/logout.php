<?php session_start(); 
 session_destroy(); 
 ?> <br>
 <br>
 <br>
 <br>
 <br>
 <br>
<meta http-equiv="refresh" content="0;url=index.php" />
 